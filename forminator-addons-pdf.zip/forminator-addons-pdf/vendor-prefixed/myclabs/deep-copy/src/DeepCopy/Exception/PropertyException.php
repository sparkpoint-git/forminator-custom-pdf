<?php

namespace ForminatorPDFAddon\DeepCopy\Exception;

use ReflectionException;
class PropertyException extends ReflectionException
{
}