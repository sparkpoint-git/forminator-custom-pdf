<?php

namespace Mpdf\Tag;

class Tt extends \Mpdf\Tag\InlineTag
{
}