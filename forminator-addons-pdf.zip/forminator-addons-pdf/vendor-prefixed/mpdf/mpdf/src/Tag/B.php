<?php

namespace Mpdf\Tag;

class B extends \Mpdf\Tag\InlineTag
{
}