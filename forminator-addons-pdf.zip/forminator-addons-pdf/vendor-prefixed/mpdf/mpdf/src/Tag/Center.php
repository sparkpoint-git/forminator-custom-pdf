<?php

namespace Mpdf\Tag;

class Center extends \Mpdf\Tag\BlockTag
{
}