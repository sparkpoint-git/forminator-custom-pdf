<?php

namespace Mpdf\Tag;

class Footer extends \Mpdf\Tag\BlockTag
{
}