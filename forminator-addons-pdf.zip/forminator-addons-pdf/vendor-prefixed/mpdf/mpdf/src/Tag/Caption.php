<?php

namespace Mpdf\Tag;

class Caption extends \Mpdf\Tag\BlockTag
{
}