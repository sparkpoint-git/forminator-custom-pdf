<?php

namespace Mpdf\Tag;

class Kbd extends \Mpdf\Tag\InlineTag
{
}