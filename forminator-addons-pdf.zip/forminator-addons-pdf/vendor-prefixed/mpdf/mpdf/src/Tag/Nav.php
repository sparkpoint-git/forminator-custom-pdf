<?php

namespace Mpdf\Tag;

class Nav extends \Mpdf\Tag\BlockTag
{
}