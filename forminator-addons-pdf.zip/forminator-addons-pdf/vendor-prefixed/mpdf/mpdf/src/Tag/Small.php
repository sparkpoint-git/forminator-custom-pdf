<?php

namespace Mpdf\Tag;

class Small extends \Mpdf\Tag\InlineTag
{
}