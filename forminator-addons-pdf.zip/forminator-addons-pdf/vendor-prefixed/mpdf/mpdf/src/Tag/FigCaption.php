<?php

namespace Mpdf\Tag;

class FigCaption extends \Mpdf\Tag\BlockTag
{
}