<?php

namespace Mpdf\Tag;

class Strike extends \Mpdf\Tag\InlineTag
{
}