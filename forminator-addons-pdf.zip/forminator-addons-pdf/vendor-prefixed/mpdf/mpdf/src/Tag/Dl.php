<?php

namespace Mpdf\Tag;

class Dl extends \Mpdf\Tag\BlockTag
{
}