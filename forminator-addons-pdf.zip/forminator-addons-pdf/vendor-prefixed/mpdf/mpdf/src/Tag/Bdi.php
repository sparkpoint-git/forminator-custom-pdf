<?php

namespace Mpdf\Tag;

class Bdi extends \Mpdf\Tag\InlineTag
{
}