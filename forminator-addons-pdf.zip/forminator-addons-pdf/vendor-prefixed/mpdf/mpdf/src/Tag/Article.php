<?php

namespace Mpdf\Tag;

class Article extends \Mpdf\Tag\BlockTag
{
}