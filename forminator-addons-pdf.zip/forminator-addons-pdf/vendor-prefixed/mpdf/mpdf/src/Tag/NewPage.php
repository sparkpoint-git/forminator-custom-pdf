<?php

namespace Mpdf\Tag;

class NewPage extends \Mpdf\Tag\FormFeed
{
}