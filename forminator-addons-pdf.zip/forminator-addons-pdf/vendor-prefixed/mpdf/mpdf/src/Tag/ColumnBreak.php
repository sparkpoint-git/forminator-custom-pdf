<?php

namespace Mpdf\Tag;

class ColumnBreak extends \Mpdf\Tag\NewColumn
{
}