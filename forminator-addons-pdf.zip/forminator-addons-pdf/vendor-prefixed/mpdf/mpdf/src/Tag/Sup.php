<?php

namespace Mpdf\Tag;

class Sup extends \Mpdf\Tag\InlineTag
{
}