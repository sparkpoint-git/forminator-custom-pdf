<?php

namespace Mpdf\Tag;

class Ins extends \Mpdf\Tag\InlineTag
{
}