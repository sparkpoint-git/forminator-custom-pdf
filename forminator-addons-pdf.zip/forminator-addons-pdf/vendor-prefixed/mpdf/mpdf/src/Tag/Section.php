<?php

namespace Mpdf\Tag;

class Section extends \Mpdf\Tag\BlockTag
{
}