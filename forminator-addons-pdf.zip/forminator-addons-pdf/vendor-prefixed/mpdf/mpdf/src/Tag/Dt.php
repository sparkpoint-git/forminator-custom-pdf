<?php

namespace Mpdf\Tag;

class Dt extends \Mpdf\Tag\BlockTag
{
}