<?php

namespace Mpdf\Tag;

class Big extends \Mpdf\Tag\InlineTag
{
}