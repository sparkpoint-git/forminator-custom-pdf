<?php

namespace Mpdf\Tag;

class Summary extends \Mpdf\Tag\BlockTag
{
}