<?php

namespace Mpdf\Tag;

class Span extends \Mpdf\Tag\InlineTag
{
}