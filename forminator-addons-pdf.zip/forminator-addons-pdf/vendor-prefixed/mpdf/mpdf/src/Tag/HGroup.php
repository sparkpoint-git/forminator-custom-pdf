<?php

namespace Mpdf\Tag;

class HGroup extends \Mpdf\Tag\BlockTag
{
}