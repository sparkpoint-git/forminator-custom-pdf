<?php

namespace Mpdf\Tag;

class Form extends \Mpdf\Tag\BlockTag
{
}