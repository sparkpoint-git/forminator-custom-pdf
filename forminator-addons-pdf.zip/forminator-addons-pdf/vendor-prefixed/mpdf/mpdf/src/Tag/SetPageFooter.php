<?php

namespace Mpdf\Tag;

class SetPageFooter extends \Mpdf\Tag\SetHtmlPageFooter
{
}