<?php

namespace Mpdf\Tag;

class H6 extends \Mpdf\Tag\BlockTag
{
}