<?php

namespace Mpdf\Tag;

class PageBreak extends \Mpdf\Tag\FormFeed
{
}