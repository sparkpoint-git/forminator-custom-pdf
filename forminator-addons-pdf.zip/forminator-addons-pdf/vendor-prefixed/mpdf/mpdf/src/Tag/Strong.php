<?php

namespace Mpdf\Tag;

class Strong extends \Mpdf\Tag\InlineTag
{
}