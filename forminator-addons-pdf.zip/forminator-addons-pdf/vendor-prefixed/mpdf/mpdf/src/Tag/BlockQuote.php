<?php

namespace Mpdf\Tag;

class BlockQuote extends \Mpdf\Tag\BlockTag
{
}