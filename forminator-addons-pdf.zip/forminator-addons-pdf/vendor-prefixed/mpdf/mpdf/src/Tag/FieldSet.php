<?php

namespace Mpdf\Tag;

class FieldSet extends \Mpdf\Tag\BlockTag
{
}