<?php

namespace Mpdf\Tag;

class H4 extends \Mpdf\Tag\BlockTag
{
}