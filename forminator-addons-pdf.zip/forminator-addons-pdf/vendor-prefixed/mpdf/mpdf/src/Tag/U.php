<?php

namespace Mpdf\Tag;

class U extends \Mpdf\Tag\InlineTag
{
}