<?php

namespace Mpdf\Tag;

class PageHeader extends \Mpdf\Tag\PageFooter
{
}