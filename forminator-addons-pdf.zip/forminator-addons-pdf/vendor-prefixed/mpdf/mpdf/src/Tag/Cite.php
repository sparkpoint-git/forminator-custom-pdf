<?php

namespace Mpdf\Tag;

class Cite extends \Mpdf\Tag\InlineTag
{
}