<?php

namespace Mpdf\Tag;

class Font extends \Mpdf\Tag\InlineTag
{
}