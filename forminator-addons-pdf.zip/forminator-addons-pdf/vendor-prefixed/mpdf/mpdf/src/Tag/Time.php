<?php

namespace Mpdf\Tag;

class Time extends \Mpdf\Tag\InlineTag
{
}