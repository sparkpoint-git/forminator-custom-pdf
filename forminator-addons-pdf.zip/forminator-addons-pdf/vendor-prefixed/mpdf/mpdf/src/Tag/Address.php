<?php

namespace Mpdf\Tag;

class Address extends \Mpdf\Tag\BlockTag
{
}