<?php

namespace Mpdf\Tag;

class Aside extends \Mpdf\Tag\BlockTag
{
}