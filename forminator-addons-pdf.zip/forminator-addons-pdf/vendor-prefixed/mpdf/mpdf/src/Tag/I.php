<?php

namespace Mpdf\Tag;

class I extends \Mpdf\Tag\InlineTag
{
}