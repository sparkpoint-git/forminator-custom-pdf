<?php

namespace Mpdf\Tag;

class Del extends \Mpdf\Tag\InlineTag
{
}