<?php

namespace Mpdf\Tag;

class Main extends \Mpdf\Tag\BlockTag
{
}