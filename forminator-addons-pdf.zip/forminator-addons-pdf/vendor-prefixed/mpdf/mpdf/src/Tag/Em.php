<?php

namespace Mpdf\Tag;

class Em extends \Mpdf\Tag\InlineTag
{
}