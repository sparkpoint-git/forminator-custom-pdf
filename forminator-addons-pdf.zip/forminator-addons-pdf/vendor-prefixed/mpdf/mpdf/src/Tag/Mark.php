<?php

namespace Mpdf\Tag;

class Mark extends \Mpdf\Tag\InlineTag
{
}