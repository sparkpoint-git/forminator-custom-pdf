<?php

namespace Mpdf\Tag;

class SetPageHeader extends \Mpdf\Tag\SetHtmlPageFooter
{
}