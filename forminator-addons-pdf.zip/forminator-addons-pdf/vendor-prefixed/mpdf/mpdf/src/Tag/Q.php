<?php

namespace Mpdf\Tag;

class Q extends \Mpdf\Tag\InlineTag
{
}