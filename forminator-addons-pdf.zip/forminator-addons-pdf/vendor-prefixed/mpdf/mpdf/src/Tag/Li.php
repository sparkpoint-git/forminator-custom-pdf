<?php

namespace Mpdf\Tag;

class Li extends \Mpdf\Tag\BlockTag
{
}