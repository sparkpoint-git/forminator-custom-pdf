<?php

namespace Mpdf\Tag;

class Figure extends \Mpdf\Tag\BlockTag
{
}