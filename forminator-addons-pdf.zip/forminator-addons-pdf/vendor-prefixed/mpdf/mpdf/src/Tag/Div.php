<?php

namespace Mpdf\Tag;

class Div extends \Mpdf\Tag\BlockTag
{
}