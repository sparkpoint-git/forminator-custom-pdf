<?php

namespace Mpdf\Tag;

class Header extends \Mpdf\Tag\BlockTag
{
}