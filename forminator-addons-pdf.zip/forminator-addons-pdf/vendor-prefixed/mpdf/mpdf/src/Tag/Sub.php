<?php

namespace Mpdf\Tag;

class Sub extends \Mpdf\Tag\InlineTag
{
}