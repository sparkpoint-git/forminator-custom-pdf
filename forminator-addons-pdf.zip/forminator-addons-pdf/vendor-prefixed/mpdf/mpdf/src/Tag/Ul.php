<?php

namespace Mpdf\Tag;

class Ul extends \Mpdf\Tag\BlockTag
{
}